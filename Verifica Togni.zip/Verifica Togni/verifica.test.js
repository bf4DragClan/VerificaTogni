const s = require('./verifica.js');

test('Controllo switch lettere', () => {
    expect(s.offusca("ciao")).toBe('C140');
    expect(s.offusca("tetto")).toBe('73770');
});


test('Calcolo', () => {
    expect(s.calcola('sin(x) + 1', 1.5)).toBe(1.9974949866040546);
});


